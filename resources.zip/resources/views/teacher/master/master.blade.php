<!DOCTYPE html>
<html lang="en">

<head>
    @include('teacher.includes.head')
</head>

<body>
   @if (session('success') || session('danger'))
    <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999">
        @if (session('success'))
        <div class="toast align-items-center text-bg-success border-0 fade hide" role="alert" data-bs-delay="4000" data-bs-autohide="true">
            <div class="d-flex">
                <div class="toast-body">
                    {{ session('success') }}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
        @endif

        @if (session('danger'))
        <div class="toast align-items-center text-bg-danger border-0 fade hide" role="alert" data-bs-delay="4000" data-bs-autohide="true">
            <div class="d-flex">
                <div class="toast-body">
                    {{ session('danger') }}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
        @endif
    </div>
   @endif

    <!-- Dashboard Layout Wrapper -->
    @include('teacher.includes.navbar')
    @yield('content')
    @include('teacher.includes.footer')
    @include('teacher.includes.scripts')
</body>

</html>
